# Cross-fitted probability pooling with a reproduced cross-benchmark prior

Idrees Aziz, idrees.mustafa.aziz@gmail.com.

The offline subject/text logistic prior is reproduced from Team Drift, Alex Alvord /
Cloud Lab Works LLC, MIT: https://github.com/cloudlabworks/aims-team-drift,
commit5a67dfcbaf8742f639edbfb96f15ee6efe3eed04. Its original runtime and
featurizer are included unchanged as drift_prior_model.py and featurize.py.
All167 listed public binary sources at measurement-db revision
54074453da7b9911be0f48e4c560be547bc84d21 enter the full deployment fit.
The10k item cap, .01 subject/text ridge and .5 benchmark weighting exponent
are unchanged. Disk-backed fitting changes floating-point reduction order;
these are retrained weights, not the original historical artifact. IDF hash
matches the original release. No raw training questions/outcomes are bundled.

Our contribution is the cross-fitted item-probability pooling and Brier stacking
layer over that prior: kappa.25, pseudo4 global calibration, solver ridge16,
stack ridge1. Gaussian adaptation extends the credited Drift baseline. Standard
Beta-binomial conjugacy and regularization are not claimed as inventions.
Only currently supplied same-benchmark labels are used; full subject/item/tool
identity, unequal counts and repeated trials are supported. No API credentials,
network calls, pretrained downloads, annotation service or GPU are required.
OpenAI Codex assisted development. NumPy/SciPy must be present in the scorer.

Validation uses benchmark-excluded prior fits, never these full-fit weights.
Broader public validation found neutral priors slightly better; the user chose
this metadata-aware prior for the final candidate. Local numbers are not hosted
scores. Dataset source licenses and terms remain applicable.
